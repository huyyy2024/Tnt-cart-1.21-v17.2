package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v4 — split pattern:
 *
 * RAIL → 2-tick Grim-safe (rotation must precede movement packet):
 *   prepareRailPlacement() → beforeSync applies rotation → executePending() tick after
 *
 * CART → direct same-tick (no rotation check by Grim for entity placement on rail):
 *   placeCartDirect() → interactBlock immediately, no rotation needed
 *
 * Lý do tách: HT1 insta cart đặt cart NGAY sau khi rail confirm,
 * không có 1-tick rotation delay. Grim không strict-check rotation
 * khi spawn entity (minecart) lên block đã tồn tại — chỉ check khi đặt block mới.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    // Pending rail interact state (2-tick pattern)
    private static volatile BlockPos pendingPos  = null;
    private static volatile int      pendingSlot = -1;
    private static volatile int      savedSlot   = -1;

    // ─── Rail: 2-tick pattern ────────────────────────────────────────────────

    /**
     * Stage 1: Chuẩn bị đặt rail.
     * Rotation được apply trong beforeSync cùng tick này,
     * interact xảy ra tick sau qua executePending().
     */
    /**
     * Stage 1: Lưu railPos + slot. KHÔNG tính rotation ở đây.
     * Rotation tính ở executePending (tick N+1) khi eyePos là vị trí thực tại thời điểm interact.
     * Bug cũ: rotation tính ở tick N → eyePos dịch chuyển khi player đang chạy
     *         → Grim raycast tick N+1 từ eyePos mới → trượt khỏi block → ghost rail.
     */
    public static void prepareRailPlacement(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        pendingPos  = railPos;
        pendingSlot = railSlot;
        savedSlot   = p.getInventory().selectedSlot;

        // setPending với rotation tạm từ tick N — sẽ bị recalc ở executePending
        // Chỉ cần để RotationUtil biết có pending, KeyboardInputMixin mới chạy
        BlockPos groundPos = railPos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);
        float[]  rot       = RotationUtil.calcRotation(p, hitVec);
        RotationUtil.setPending(p, rot);
    }

    /**
     * Stage 2: Tính lại rotation từ eyePos HIỆN TẠI (tick N+1), rồi interact.
     * eyePos tick N+1 khớp với movement packet tick N+1 Grim đang xử lý
     * → raycast từ đó trúng block → không ghost.
     */
    public static boolean executePending(MinecraftClient mc) {
        if (pendingPos == null) return false;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) { clearPending(); return false; }

        BlockPos pos      = pendingPos;
        int      slot     = pendingSlot;
        int      origSlot = savedSlot;

        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;

        BlockPos groundPos = pos.down();
        Vec3d    hitVec    = RotationUtil.calcHitVec(groundPos, Direction.UP);

        // Tính lại rotation từ eyePos tick N+1 — fresh, bù được movement
        float[] rot = RotationUtil.calcRotation(p, hitVec);
        RotationUtil.updatePending(rot);    // cập nhật rot trong RotationUtil trước beforeSync đã chạy
        RotationUtil.applyRawNow(p, rot);  // apply trực tiếp vì beforeSync tick này đã qua

        p.getInventory().selectedSlot = slot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, groundPos, false));
        p.getInventory().selectedSlot = origSlot;

        RotationUtil.restoreAfterInteract(p);
        return true;
    }

    // ─── Cart: direct same-tick ───────────────────────────────────────────────

    /**
     * Đặt cart trực tiếp — không cần 2-tick rotation.
     * Grim không check rotation khi spawn entity lên rail.
     * Gọi ngay khi rail confirmed exist trong world.
     *
     * @return true nếu interact packet đã gửi
     */
    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;

        // Tính rotation để look at rail — gửi nhưng không block
        Vec3d   hitVec   = RotationUtil.calcHitVec(railPos, Direction.UP);
        float[] rot      = RotationUtil.calcRotation(p, hitVec);
        float   savedYaw = p.getYaw();
        float   savedPit = p.getPitch();

        // Apply rotation tạm (đủ để hit vector hợp lệ)
        p.setYaw(rot[0]); p.setPitch(rot[1]);
        p.headYaw = rot[0]; p.bodyYaw = rot[0];

        int origSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = cartSlot;
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        p.getInventory().selectedSlot = origSlot;

        // Restore ngay — cart không cần movement packet backup
        p.setYaw(savedYaw); p.setPitch(savedPit);
        p.headYaw = savedYaw; p.bodyYaw = savedYaw;
        return true;
    }

    public static boolean hasPending() { return pendingPos != null; }

    public static void clearPending() {
        pendingPos  = null;
        pendingSlot = -1;
        savedSlot   = -1;
        RotationUtil.restoreAfterInteract(MinecraftClient.getInstance().player);
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
